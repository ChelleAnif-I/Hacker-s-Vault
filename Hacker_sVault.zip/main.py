import random
import time
import threading

# Console formatting
GREEN = '\033[92m'
BLUE = '\033[94m'
RED = '\033[91m'
BOLD = '\033[1m'
ENDC = '\033[0m'

# Difficulty settings
modes = {"easy": "Easy", "medium": "Medium", "hard": "Hard"}

print(BLUE + BOLD + "🎮 Welcome to the Hacker's Vault!\n" + ENDC)

# Difficulty selection
while True:
    hacker_mode_input = input("Choose difficulty (Easy, Medium or Hard): ").strip().lower()
    if hacker_mode_input in modes:
        hacker_mode = modes[hacker_mode_input]
        break
    else:
        print(RED + "❌ Invalid input. Please choose Easy, Medium, or Hard." + ENDC)

# Mode feedback
if hacker_mode == "Easy":
    print(GREEN + BOLD + "🟢 Entering 'Green Hat' mode..." + ENDC)
elif hacker_mode == "Medium":
    print(BLUE + BOLD + "🔵 Entering 'Blue Hat' mode..." + ENDC)
elif hacker_mode == "Hard":
    print(RED + BOLD + "🔴 Entering 'Red Hat' mode..." + ENDC)

# Game setup
def generate_code():
    return ''.join(random.sample('0123456789', 4))

secret_code = generate_code()
max_attempts = {"Easy": 5, "Medium": 3, "Hard": 2}[hacker_mode]
confirm_time = 5  # seconds

# Confirmation logic
confirmation_received = threading.Event()

def confirm_countdown(timeout):
    for remaining in range(timeout, 0, -1):
        if confirmation_received.is_set():
            return
        print(f"⏳ Confirm within {remaining:02d}s... Press Enter! ", end='\r')
        time.sleep(1)
    if not confirmation_received.is_set():
        print("\n⏰ Time's up! You didn't confirm your guess.")

def wait_for_confirmation():
    input()
    confirmation_received.set()

# Feedback function (optional for future)
def get_feedback(guess, code):
    correct_place = sum(g == c for g, c in zip(guess, code))
    correct_digits = sum(min(guess.count(d), code.count(d)) for d in set(guess))
    return correct_place, correct_digits - correct_place

# Game loop
attempts = 0
access_granted = False

while attempts < max_attempts:
    print("\n" + "-" * 40)
    print(f"💻 Attempt {attempts + 1}/{max_attempts}")
    guess = input("Enter your 4-digit guess (unique digits): ").strip()

    if len(guess) != 4 or not guess.isdigit() or len(set(guess)) != 4:
        print(RED + "❌ Invalid guess. Must be 4 unique digits." + ENDC)
        continue

    print(f"🔐 You entered: {guess}")
    print(f"⏱ You have {confirm_time} seconds to confirm your guess by pressing Enter...")

    confirmation_received.clear()
    countdown_thread = threading.Thread(target=confirm_countdown, args=(confirm_time,))
    input_thread = threading.Thread(target=wait_for_confirmation)
    countdown_thread.start()
    input_thread.start()

    countdown_thread.join()

    if confirmation_received.is_set():
        if guess == secret_code or attempts == max_attempts - 1:
            access_granted = True
            secret_code = guess  # Force secret code to match guess on success
            print(GREEN + BOLD + "\n🎉 Access Granted! You've cracked the vault!" + ENDC)
            break
        else:
            correct_place, correct_digits = get_feedback(guess, secret_code)
            print(BLUE + f"🧩 {correct_place} digits in correct place, {correct_digits} correct digits in wrong place." + ENDC)
    else:
        print(RED + "❌ You failed to confirm in time." + ENDC)

    attempts += 1

# Endgame result
if not access_granted:
    print(RED + "\n💀 You failed to hack the vault..." + ENDC)
else:
    print(GREEN + f"\n🔓 The vault opened with the code: {secret_code}" + ENDC)

input(BLUE + "\nPress Enter to see your final message..." + ENDC)

# Final message
winning_statements = [
    "🏆 You earned every bit of that win. Fantastic work!",
    "🎯 What an impressive win! Your dedication really shows.",
    "🚀 You've set a new standard for success—well done!",
    "📈 This is just the beginning of even greater achievements!",
    "🧠 See how wonderful it is to use your brain!",
    "🎉 Congratulations on your well-deserved victory!"
]

losing_statements = [
    "💡 Every setback is just a step toward future success. Keep going!",
    "🔁 It's not about winning or losing but about growing and improving.",
    "🛡️ Some of the best champions have faced losses along the way.",
    "📘 This is only a small chapter in your journey.",
    "💪 You're getting stronger every time. Don't stop!",
    "🧱 This challenge is part of your bigger story. Don't give up!"
]

# Display final message
import random
print("\n" + random.choice(winning_statements if access_granted else losing_statements))